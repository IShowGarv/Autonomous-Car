Step 1 - Download Udacity Car Simulator (https://github.com/udacity/self-driving-car-sim)
Step 2 - open and run traning mode
Step 3 - Record data and images in this folder
